<template>
<div>
    <ordered-select
        ref="dropdown"
        :options="authors"
        :options-limit="100"
        v-model="selectedAuthor"
        :custom-label="authorLabels"
        :close-on-select="true"
        :show-labels="false"
        @select="closeDropdown()"
        :multiple="multiple"
        :id="anchor"
        :class="customCssClasses.replace(/[^a-z0-9\-\_\s]/gmi, '')"
        :placeholder="placeholder"></ordered-select>
</div>
</template>

<script>
import OrderedSelect from './OrderedSelect.vue';

export default {
    components: {
        OrderedSelect
    },
    name: 'authors-dropdown',
    props: {
        multiple: {
            type: Boolean,
            default: false
        },
        value: {},
        anchor: {
            type: String,
            default: '',
        },
        customCssClasses: {
            default: '',
            type: String
        }
    },
    data () {
        return {
            selectedAuthor: ''
        };
    },
    computed: {
        authors () {
            return [''].concat(this.$store.state.currentSite.authors.slice().sort((a, b) => {
                return a.username.localeCompare(b.username);
            }).map(author => author.id));
        },
        placeholder () {
            return this.$t('author.selectAuthor');
        },
        authorNamesById () {
            let map = new Map();

            for (let author of this.$store.state.currentSite.authors) {
                map.set(author.id, author.name);
            }

            return map;
        }
    },
    watch: {
        value: function (newValue, oldValue) {
            this.selectedAuthor = newValue;
        },
        selectedAuthor: function (newValue, oldValue) {
            this.$emit('input', this.selectedAuthor);
        }
    },
    mounted () {
        if (this.value) {
            this.selectedAuthor = this.value;
        }
    },
    methods: {
        authorLabels (value) {
            return this.authorNamesById.get(value);
        },
        closeDropdown () {
            this.$refs['dropdown'].deactivate();
        }
    }
}
</script>

<style>
.multiselect {
    line-height: 2;
}

.multiselect,
.multiselect__tags {
    min-height: 49px;
}

.multiselect__tags {
    padding: 0 var(--space-16) 0 1.8rem;
}

.multiselect__input {
    max-width: 100%;
}
</style>
